const { BOT_PHONE } = require("./settings.json")

exports.verifyPermissions = async(sock, from, participant) =>{
  
  try{
    
    const { participants = [], owner= null } = await sock.groupMetadata(from) || {};
    
    if(!participants.length){
      return null
    }
    
    const admins = participants?.filter(user => user.admin == "admin" || user.admin == "superadmin");
    
    const isAdmin = !!admins.find(admin => admin.id == participant)
    
    const isBotAdmin = !!admins.find(admin => admin.id.includes(BOT_PHONE))
    
    const isOwnerGroup = owner;
    
    return{
      isAdmin,
      isBotAdmin,
      isOwnerGroup
    }
    
    
  }catch(error){
    console.log(error)
  }
  
}