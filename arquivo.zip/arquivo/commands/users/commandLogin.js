const fs = require("fs");

exports.commandLogin = async(searchUserLogin, enviarMensagem, args, from, participant, reagir) =>{
  
  const date = new Date();
  
  const login = JSON.parse(fs.readFileSync("data/login.json"))
  
  if(searchUserLogin){
    await enviarMensagem('Voce ja esta registrado!')
    return
  }
  
  if(!args){
    await enviarMensagem("Voce deve digitar um apelido ou seu nome para se registrar!")
    return
  }
  
  let objectLogin = {
    grupo: from,
    user: participant,
    info: [
      {
        apelido: args,
        totalMensagens: 0,
        saldo: 0,
        data: date.toLocaleDateString("pt-br")
      }
      ]
  }
  
  login.push(objectLogin)
  fs.writeFileSync("data/login.json", JSON.stringify(login, null, 3))
  
  await reagir("");
  await enviarMensagem("Voce foi registrado com sucesso e ja pode usar meus comandos!")
  
  
  
}