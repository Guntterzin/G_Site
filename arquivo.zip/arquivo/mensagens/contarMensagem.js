exports.contarMensagem = async(messageDetails, from, participant) =>{
  
  const fs = require("fs")
  
  
  const login = JSON.parse(fs.readFileSync("data/login.json"))
  
  const searchUserLogin = login?.find((grupos) => grupos.grupo == from && grupos.user == participant)
  
  if(searchUserLogin && messageDetails){
    
    const totalMensagens = searchUserLogin.info[0].totalMensagens;
    const novoTotal = totalMensagens+1;
    
    searchUserLogin.info[0].totalMensagens = novoTotal
    
    fs.writeFileSync("data/login.json", JSON.stringify(login, null, 3))
  }
  
  return searchUserLogin
  
}